# Wigii Natural Code Development addon
Wigii Natural Code Development addon is an html/javascript library used to help teach and learn programming principles using HTML and Javascript languages. This library is open-source and used in the context of the ATELIER ENCODE! course, given by the Wigii.org non-profit organisation in Switzerland. See https://www.atelierencode.ch
